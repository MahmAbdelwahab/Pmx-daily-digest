ER_mod <- function(data, prob = T, ref_prob = 0.5, slp = 1,
                   bs_AGE = 1, bs_BLDH = 1, bs_WT = 1, bs_SEX = 1, 
                   bs_ECOGGE1 = 1, bs_HB = 1, bs_ANC = 1, bs_PLT = 1,
                   bs_HEP = 1, bs_White = 1, bs_Black = 1, bs_LOC = 1,
                   slp_AGE = 1, slp_BLDH = 1, slp_WT = 1, slp_SEX = 1,
                   slp_ECOGGE1 = 1, slp_HB = 1, slp_ANC = 1, slp_PLT = 1,
                   slp_HEP = 1, slp_White = 1, slp_Black = 1, slp_LOC = 1){
  int <- log(ref_prob/(1-ref_prob))
  
  #drug effect
  int_AUCSS <- log(slp)/250*(data$AUCSS-375)
  
  #effect on int
  int_AGE <- log(bs_AGE)*(data$AGE-65)/10
  int_BLDH <- log(bs_BLDH)*(data$BLDH-250)/300
  int_WT <- log(bs_WT)*(data$WT-63)/20
  int_SEX <- log(bs_SEX)*(data$SEX)
  int_ECOGGE1 <- log(bs_ECOGGE1)*(data$ECOGGE1)
  int_HB <- log(bs_HB)*(data$HB-117)/20
  int_ANC <- log(bs_ANC)*(data$ANC-3.9)/2.5
  int_PLT <- log(bs_PLT)*(data$PLT-210)/110
  int_HEP <- log(bs_HEP)*data$HEPAT
  int_RACE <- 0 #Asian
  if(data$RACE == 2){ #White
    int_RACE <- log(bs_White)
  }else if(data$RACE == 3){ #Black
    int_RACE <- log(bs_Black)
  }
  int_LOC <- log(bs_LOC)*data$LOCATION #USA
  int_eff <- int+int_AGE+int_BLDH+int_WT+int_SEX+int_ECOGGE1+int_HB+int_ANC+int_PLT+int_HEP+int_RACE+int_LOC
  
  
  #effect on slp (interaction)
  de_AGE <- log(slp_AGE)/10*(data$AGE-65)
  de_BLDH <- log(slp_BLDH)/300*(data$BLDH-250)
  de_WT <- log(slp_WT)/20*(data$WT-63)
  de_SEX <- log(slp_SEX)*(data$SEX)
  de_ECOGGE1 <- log(slp_ECOGGE1)*(data$ECOGGE1)
  de_HB <- log(slp_HB)*(data$HB-117)/20
  de_ANC <- log(slp_ANC)*(data$ANC-3.9)/2.5
  de_PLT <- log(slp_PLT)*(data$PLT-210)/110
  de_HEP <- log(slp_HEP)*data$HEPAT
  de_RACE <- 0 #Asian
  if(data$RACE == 2){ #White
    de_RACE <- log(slp_White)
  }else if(data$RACE == 3){ #Black
    de_RACE <- log(slp_Black)
  }
  de_LOC <- log(slp_LOC)*data$LOCATION #USA
  
  slp_cov <- (de_AGE+de_BLDH+de_WT+de_SEX+de_ECOGGE1+de_HB+de_ANC+de_PLT+de_HEP+de_RACE+de_LOC)
  deff <- int_AUCSS+slp_cov*(data$AUCSS-375)/250
  
  mu <- int_eff + deff
  #c(exp(mu),plogis(mu))
  if(prob){
    plogis(mu)
  }else{
    mu
  }
  
}

# 5: Grade ? 3 PLT decrease
ER_5a <- function(data, prob){
  ER_mod(data = data, prob = prob, ref_prob = 0.165, slp = 2.03,
         bs_AGE = 1, bs_BLDH = 1.1, bs_WT = 0.95, bs_SEX = 1.2, 
         bs_ECOGGE1 = 1, bs_HB = 1, bs_ANC = 1, bs_PLT = 0.230,
         bs_HEP = 1.1, bs_White = 1.15, bs_Black = 1.15, bs_LOC = 1,
         slp_AGE = 1, slp_BLDH = 1, slp_WT = 1, slp_SEX = 1,
         slp_ECOGGE1 = 1, slp_HB = 1, slp_ANC = 1, slp_PLT = 1,
         slp_HEP = 1, slp_White = 1, slp_Black = 1,  slp_LOC = 1)
}


# 8: Dose reduction due to TEAE
ER_8a <- function(data, prob){
  ER_mod(data = data, prob = prob, ref_prob = 0.1074, slp = 1.79,
         bs_AGE = 1, bs_BLDH = 1.15, bs_WT = 0.95, bs_SEX = 1.3, 
         bs_ECOGGE1 = 1, bs_HB = 1, bs_ANC = 1, bs_PLT = 1,
         bs_HEP = 1.15, bs_White = 1.1, bs_Black = 1.1, bs_LOC = 1,
         slp_AGE = 1, slp_BLDH = 1, slp_WT = 1, slp_SEX = 1,
         slp_ECOGGE1 = 1, slp_HB = 1, slp_ANC = 1, slp_PLT = 1,
         slp_HEP = 1, slp_White = 1, slp_Black = 1, slp_LOC = 1)
}

ER_sim <- function(dt, prob = T){
  Prob <- c(ER_5a(dt, prob = prob), ER_8a(dt, prob = prob))
  data.frame(dt, FLAG = c(5,8)) %>% 
    mutate(prob = Prob) %>%
    group_by(FLAG) %>%
    group_split() %>%
    map_df(function(dtflag){
      dtflag %>% mutate(DV = rbinom(1,1,prob))
    })
}



rm(list=ls())
library(mrgsolve)
library(data.table)
library(Hmisc)
library(ggpubr)
library(MASS)
library(tidyverse)

# load obs data
obs_df <- read.csv("data_101201.csv")
head(obs_df)

# load mrgsolve model
source("new_poppk_mrgsolve.r")
n <- length(unique(obs_df$ID))
set.seed(12313)
ETA <- mvrnorm(n = n, mu = c(0, 0, 0, 0, 0), Sigma = varcov) %>% as.data.frame()
ETA$ID <- unique(obs_df$ID)
dim(ETA)

obs_df2 <- obs_df %>%
  merge(ETA, by = "ID") %>%
  rename(ETA1 = V1, ETA2 = V2, ETA3 = V3, ETA4 = V4, ETA5 = V5)

# Model parameters
modpars <- allparam(mod) %>% names()

# PK simulation
PK_df <- mod %>%
  data_set(obs_df2) %>%
  mrgsim_df(carry_out = c("ID","STUDY","DOSE", "EVID", "SEQ"), obsonly=TRUE) %>%
  as.data.table() 

exposure_obs_df <- PK_df %>%
  filter(EVID == 0, SEQ == 1) %>%
  group_by(ID, STUDY, DOSE) %>%
  mutate(AUCSS = c(-999, diff(AUCFREE))) %>%
  filter(AUCSS!=-999) %>%
  #add random error to AUCSS
  #mutate(AUCSS = AUCSS*exp(RUV)) %>%
  ungroup() %>%
  arrange(STUDY, ID) %>%
  dplyr::select(ID, STUDY, AUCSS) %>%
  merge(obs_df %>% distinct(ID, STUDY, DOSE, .keep_all = T) %>% 
          dplyr::select(-TIME), 
        by = c("ID", "STUDY")) 
head(exposure_obs_df)
write.csv(exposure_obs_df,"exposure_obs_data.csv", row.names = F, quote = F)

# calculate incidence rate and simulate AE
source("new_ER_models.r")
set.seed(12345)
sim.dt <- exposure_obs_df %>% 
  group_by(STUDY,ID) %>%
  group_split() %>%
  map_df(function(dt){
    ER_sim(dt)
  })
colnames(sim.dt)

write.csv(sim.dt, "AE_data.csv", quote = F, row.names = F)

# simulate true PK and true AE prob for 150, 200, 250, 300 for obs_df2
# ETA != 0
# this is true rate for the simulated data obs_df2
exposure_sample_multidose <- NULL
# PK simulation
for(dose in c(150, 200, 250, 300)){
  PK_df0 <- mod %>%
    data_set(obs_df2 %>% mutate(DOSE = dose, AMT = dose)) %>%
    mrgsim_df(carry_out = c("ID","STUDY","DOSE", "EVID", "SEQ"), obsonly=TRUE) %>%
    as.data.table() 
  
  exposure_obs_df0 <- PK_df0 %>%
    filter(EVID == 0, SEQ == 1) %>%
    group_by(ID, STUDY, DOSE) %>%
    mutate(AUCSS = c(-999, diff(AUCFREE))) %>%
    filter(AUCSS!=-999) %>%
    #add random error to AUCSS
    #mutate(AUCSS = AUCSS*exp(RUV)) %>%
    ungroup() %>%
    arrange(STUDY, ID) %>%
    dplyr::select(ID, STUDY, AUCSS, DOSE) %>%
    merge(obs_df %>% distinct(ID, STUDY, .keep_all = T) %>% 
            dplyr::select(-TIME, -DOSE, -AMT), 
          by = c("ID", "STUDY"))
  exposure_sample_multidose <- rbind(exposure_sample_multidose, exposure_obs_df0)
}

sim.dt0 <- exposure_sample_multidose %>% 
  group_by(STUDY,ID, DOSE) %>%
  group_split() %>%
  map_df(function(dt){
    ER_sim(dt)
  })

sim.dt0 %>% filter(ATLL==1) %>%
  group_by(DOSE, FLAG) %>%
  summarise(mean = mean(prob), AUCSS = mean(AUCSS)) %>%
  pivot_wider(names_from = "FLAG", values_from = "mean")

write.csv(sim.dt0, "sample_true_prob.csv", row.names = F, quote = F)
# ------------------------------------------------------------------------------

##############################################
# 1000 simulations for PK and for AE   #######
##############################################
set.seed(2025)
trial.dt <- 1:1000 %>%
  map_df(function(trial){
    ETA <- mvrnorm(n = n, mu = c(0, 0, 0, 0, 0), Sigma = varcov) %>% as.data.frame()
    ETA$ID <- unique(obs_df$ID)
    dim(ETA)
    
    obs_df2 <- obs_df %>%
      merge(ETA, by = "ID") %>%
      rename(ETA1 = V1, ETA2 = V2, ETA3 = V3, ETA4 = V4, ETA5 = V5)
    
    PK_df <- mod %>%
      data_set(obs_df2) %>%
      mrgsim_df(carry_out = c("ID","STUDY","DOSE", "EVID", "SEQ"), obsonly=TRUE) %>%
      as.data.table() 
    
    exposure_obs_df <- PK_df %>%
      filter(EVID == 0, SEQ == 1) %>%
      group_by(ID, STUDY, DOSE) %>%
      mutate(AUCSS = c(-999, diff(AUCFREE))) %>%
      filter(AUCSS!=-999) %>%
      #add random error to AUCSS
      #mutate(AUCSS = AUCSS*exp(RUV)) %>%
      ungroup() %>%
      arrange(STUDY, ID) %>%
      dplyr::select(ID, STUDY, AUCSS) %>%
      merge(obs_df %>% distinct(ID, STUDY, .keep_all = T) %>% dplyr::select(-TIME), by = c("ID", "STUDY"))
    
    sim.dt <- exposure_obs_df %>% 
      group_by(STUDY,ID) %>%
      group_split() %>%
      map_df(function(dt){
        ER_sim(dt)
      }) %>%
      mutate(SIM = trial)
    
    sim.dt
  })

save(trial.dt, file = "trials.Rdata")

trial.dt %>% filter(ATLL==1) %>%
  group_by(DOSE, FLAG) %>%
  summarise(mean = mean(prob))

rm("trial.dt")

####################################################
# 1000 simulations for true incidence rate   #######
####################################################
set.seed(2025)
trial.true <- 1:1000 %>%
  map_df(function(trial){
    ETA <- mvrnorm(n = n, mu = c(0, 0, 0, 0, 0), Sigma = varcov) %>% as.data.frame()
    ETA$ID <- unique(obs_df$ID)
    dim(ETA)
    
    obs_df2 <- obs_df %>%
      merge(ETA, by = "ID") %>%
      rename(ETA1 = V1, ETA2 = V2, ETA3 = V3, ETA4 = V4, ETA5 = V5)
    obs_df3 <- obs_df2 %>% mutate(DOSE = 150, AMT = 150) %>%
      rbind(obs_df2 %>% mutate(DOSE = 200, AMT = 200)) %>%
      rbind(obs_df2 %>% mutate(DOSE = 250, AMT = 250)) %>%
      rbind(obs_df2 %>% mutate(DOSE = 300, AMT = 300)) %>%
      arrange(DOSE,STUDY,ID,TIME)
    PK_df <- mod %>%
      data_set(obs_df3) %>%
      mrgsim_df(carry_out = c("ID","STUDY","DOSE", "EVID", "SEQ"), obsonly=TRUE) %>%
      as.data.table() 
    
    exposure_obs_df <- PK_df %>%
      filter(EVID == 0, SEQ == 1) %>%
      group_by(ID, STUDY, DOSE) %>%
      mutate(AUCSS = c(-999, diff(AUCFREE))) %>%
      filter(AUCSS!=-999) %>%
      #add random error to AUCSS
      #mutate(AUCSS = AUCSS*exp(RUV)) %>%
      ungroup() %>%
      arrange(STUDY, ID,DOSE) %>%
      dplyr::select(ID, STUDY, DOSE, AUCSS) %>%
      merge(obs_df %>% distinct(ID, STUDY, .keep_all = T) %>% dplyr::select(-TIME,-AMT,-DOSE), by = c("ID", "STUDY"))
    
    sim.dt <- exposure_obs_df %>% 
      group_by(STUDY,ID,DOSE) %>%
      group_split() %>%
      map_df(function(dt){
        ER_sim(dt)
      }) %>%
      mutate(SIM = trial)
    
    sim.dt
  })

id.true <- trial.true %>% 
  group_by(ID,DOSE,FLAG,STUDY) %>%
  summarise(mean.prob = mean(prob),
            mean.AUCSS = mean(AUCSS)) %>%
  merge(sim.dt0, by=c("ID","DOSE","FLAG","STUDY"))
dim(id.true)
write.csv(id.true, "true_incidence_pred_sim.csv", quote = F, row.names = F)
# ------------------------------------------------------------------------------
# Remove all current objects in the workspace
rm(list = ls(all = TRUE))
# ------------------------------------------------------------------------------  
  
# Define variance-covariance matrix of random effects
#varcov <- diag(c(0.0395, 0.850, 0.0445, 0.343, 1.41))
varcov <- diag(c(0.02, 0.02, 0.04, 0.01, 0.02))
# ------------------------------------------------------------------------------
# Define the model parameters and equations
# This compiled model is used for simulating n individuals and their
# concentration-time profiles
code <- '

$CMT DEPOT CENT PERI PERI2 AUCTOT AUCFREE

$MAIN

// STUDY FLAGS
double FL106 = 0;
if(STUDY==106) FL106 = 1;
double FL101 = 0;
if(STUDY==101) FL101 = 1;
// PATIENT/HEALTHY
double PAT = 0;
if(POP==1) PAT = 1;
double HLTH = 1 - PAT;
// ASIAN/NONASIAN;
double ASIAN = 0;
if(RACE==1) ASIAN = 1;
double NONASIAN = 1 - ASIAN;
// Male / Female
double FEMALE = SEX;
double HEP1 = 0;
if(HEPAT==1) HEP1 = 1;
double HEP2 = 0;
if(HEPAT>=2) HEP2 = 1;
double HEP = 0;
if(HEPAT>=1) HEP = 1;
double REFWT = 63;
double REFALB = 3.9;
double REFRF = 73;
double REFAAG = 87;
// COVARIATES ON CL
double WTCL = THETA14*log(WT/REFWT);
double ALBCL = THETA15*log(ALB/REFALB);
double RFCL = THETA16*log(CLCR/REFRF);
double DZCL = THETA17*HLTH;
double NASCL = THETA18*NONASIAN;
double SXCL = THETA19*FEMALE;
double HPCL = THETA20*HEP;
double AAGCL = THETA24*log(AAG/REFAAG);
double U6CL = THETA26*FL106;
double WTV = THETA21*log(WT/REFWT);
double ALBV = THETA22*log(ALB/REFALB);
double AAGV = THETA23*log(AAG/REFAAG);
double U6V = THETA25*FL106;
double TVCL = THETA1+WTCL+ALBCL+RFCL+DZCL+NASCL+SXCL+HPCL+AAGCL+U6CL;

// Individual PK parameters
double CL = exp(TVCL + ETA1);
double V2 = exp(THETA2+U6V);
double Q3 = exp(THETA3);
double TVV3 = THETA4+WTV+ALBV+AAGV+U6V;
double V3 = exp(TVV3);
double Q4 = exp(THETA10);
double V4 = exp(THETA11+WTV+U6V);
double KA = exp(THETA5 + ETA2);
double TVD1 = THETA6*(1-FL106) + THETA12*FL106;
double D1 = exp(TVD1 + ETA5);
double KSS = exp(THETA7);
double TVRMAX = THETA8 + THETA13*log(AAG/REFAAG);
double RMAX = exp(TVRMAX + ETA3);
double ASSY = exp(THETA9*FL101);
double F1 = exp(AAGCL + ETA4);
double S2 = V2/1000;
double K20 = CL/V2;
double K23 = Q3/V2;
double K32 = Q3/V3;
double K24 = Q4/V2;
double K42 = Q4/V4;

F_DEPOT = F1;
D_DEPOT = D1;

// Initial conditions for compartments
DEPOT_0 = 0;
CENT_0 = 0;
PERI_0 = 0;
PERI2_0 = 0;
AUCTOT_0 = 0;
AUCFREE_0 = 0;

$ODE
// Concentration in compartments
double CP = CENT/S2;
double CONC = (0.5*(CP-RMAX-KSS)+0.5*sqrt((CP-RMAX-KSS)*(CP-RMAX-KSS)+4*KSS*CP));
double AC = CONC * S2;

// Differential equations
dxdt_DEPOT = -KA*DEPOT;
dxdt_CENT = KA*DEPOT - (K20+K23+K24)*AC + K32*PERI + K42*PERI2;
dxdt_PERI = K23*AC - K32*PERI;
dxdt_PERI2 = K24*AC - K42*PERI2;
dxdt_AUCTOT = CP;
dxdt_AUCFREE = CONC*ASSY;

$PARAM // Population parameters
THETA1 = 6.109,//;log450 ; 1TVCL
THETA2 =   4.566,//;log96.2 ; 2TVV2
THETA3 =   3.555,//;log35 ; 3TVQ3
THETA4 =   8.149,//;log3460 ; 4TVV3
THETA5 =   -0.524,//;log0.592  ; 5TVKA
THETA6 =   -0.272,//;log0.762  ; 6TVD1
THETA7 =   4.804,//;log122  ; 7TVKD
THETA8 =   8.412,//;log4500 ; 8TVRMAX
THETA9 =   -0.05,//;log0.671 ; 9TVASSAY
THETA10 =   5.338,//;log208  ; 10TVQ4
THETA11 =   7.701,//;log2210  ; 11TVV4
THETA12 =   -0.05,//;log0.762 ; 12TVU106D1
THETA13 =   -0.0000049,//;log0.952 ; 13TVAAGRMAX
THETA14 =   0.75,//; 14TVWTCL
THETA15 =   0,//; 15TVALBCL
THETA16 =   0.1,//; orig log1 ; 16TVRFCL
THETA17 =   0.1,//;log1.21 ; 17TVDXCL
THETA18 =   -0.1,//;orig log0.978 ; 18TVnonASIANCL
THETA19 =   -0.1,//;orig log1.05 ; 19TVFEMALECL
THETA20 =   -0.1,//;orig log0.876 ; 20TVHEPARTANYCL
THETA21 =   1,// ; 21TVWTV34
THETA22 =   0,// FIX; 22TVALBV3
THETA23 =   0,// FIX; 23TVAAGV3
THETA24 =   0.1,// ; orig 0.54; 24TVAAGCL
THETA25 =   0,//;orig log1.29 ; 25TVU106V
THETA26 =   0,//;orig log0.736 ; 26TVU106CL
// Random effects
ETA1 = 0, // Random effect on CL
ETA2 = 0, // Random effect on KA
ETA3 = 0, // Random effect on RMAX
ETA4 = 0, // Random effect on F1
ETA5 = 0, // Random effect on D1

//Covariates
STUDY = 100,
POP = 0,
RACE = 1,
SEX = 0,
HEPAT = 0,
WT = 70,
ALB = 3.9,
CLCR = 73,
AAG = 87,
SEQ = 1,
AGE = 65,
DOSE = 100,
ECOGGE1 = 0,
HB = 117,
ANC = 2.9,
LOCATION = 1,
BLDH = 250,
PLT = 210

$SIGMA @annotated
ERR1: 0.328 :
ERR2: 0.341 :
ERR3: 0.417 :

$TABLE
double CALLFL = 0;
double CTOT = CENT/S2;
double CFREE = (0.5*(CTOT-RMAX-KSS)+0.5*sqrt((CTOT-RMAX-KSS)*(CTOT-RMAX-KSS)+4*KSS*CTOT));
CFREE = CFREE*ASSY;
double AUCTOT1 = AUCTOT;
double AUCFREE1 = AUCFREE;

double TOTFL = 1;
if(SEQ==2) TOTFL = 0;
double IPRED = log(0.000001);
if(CTOT>0) IPRED = log(CTOT*TOTFL + CFREE*(1-TOTFL));
double RUV = ERR1;
if(SEQ==2) RUV = ERR2*(1-FL101) + ERR3*FL101;
double Y = IPRED + RUV;

$CAPTURE
POP CTOT CFREE RUV RACE SEX HEPAT AGE WT ALB CLCR AAG ECOGGE1 HB ANC LOCATION BLDH PLT
'
# Compile the model code
mod <- mcode("poppk",code)

rm(list=ls())

library(tidyverse)
library(mrgsolve)
library(data.table)
library(Hmisc)
library(ggpubr)

#source("SumTableFunctions.R")

#### load data ####
obs <- read.csv("AE_data.csv")%>%
  mutate(CRCL_f = ifelse(CLCR <= 60, 1, 0)) %>%
  mutate(SEX = factor(SEX, levels = c(0,1), labels = c("Male", "Female")),
         ECOGGE1 = factor(ECOGGE1, levels = c(0,1), labels = c("=0", ">=1")),
         HEPAT = factor(HEPAT, levels = c(0,1), labels = c("Normal", "Mild")),
         RACE = factor(RACE, levels = c(1,2,3), labels = c("Asian", "White", "Black")),
         LOCATION = factor(LOCATION, levels = c(0,1), labels = c("Japan", "USA")),
         CRCL_f = factor(CRCL_f, levels = c(0,1), labels = c(">60 mL/min", "<=60 mL/min"))) 
id_df <- obs %>%
  distinct(ID, STUDY, DOSE, .keep_all = T)


#######################################################################
################# function for D-E-R and D-R ##########################
#######################################################################
model.DER <- function(dt, output = NULL, model.object = TRUE, data.save = TRUE){
  # Dose - Exposure model and prediction
  id_df <- dt %>%
    distinct(ID, STUDY, DOSE, .keep_all = T) %>%
    mutate(AUCSSnorm = AUCSS/DOSE)
  #plot(id_df$DOSE,id_df$AUCSSnorm)
  #plot(id_df$DOSE,id_df$AUCSS)
  DE.m <- lm(log(AUCSSnorm)~DOSE*(WT+HEPAT+CLCR+AAG+RACE+SEX), data = id_df)
  summary(DE.m)
  #plot((id_df$AUCSS),exp(DE.m$fitted.values)*id_df$DOSE)
  #abline(a = 0, b = 1, col = "blue")
  # prediction for the data
  prednorm <- predict(DE.m, newdata = dt) %>% exp()
  pred <- prednorm*dt$DOSE
  dt.new <- dt %>% mutate(pred.AUCSS = pred)
  
  # prediction for new doses
  pre.obs.shell <- rbind(dt %>% mutate(DOSE = 150, AMT = 150),
                         dt %>% mutate(DOSE = 200, AMT = 200),
                         dt %>% mutate(DOSE = 250, AMT = 250),
                         dt %>% mutate(DOSE = 300, AMT = 300))
  AUCSSnorm.pre <- predict(DE.m, newdata = pre.obs.shell) %>% exp()
  AUCSS.pre <- AUCSSnorm.pre*pre.obs.shell$DOSE
  pre.obs.AUCSS <- pre.obs.shell %>% mutate(pred.AUCSS = AUCSS.pre)
  
  # Exposure - Response models and predictions
  #### Dose reduction ####
  ae.1 <- dt.new %>% filter(FLAG == 8)
  # include BLDH, RACE, HEPAT ANY, WT
  AE1.m <- glm(DV~(pred.AUCSS)+(BLDH+HEPAT+RACE+SEX), family = "binomial", data = ae.1)

  #### PLT decrease ####
  ae.2 <- dt.new %>% filter(FLAG == 5)
  # include BLDH, RACE, HEPAT ANY, (baseline) PLT
  AE2.m <- glm(DV~(pred.AUCSS)+(BLDH+HEPAT+RACE+SEX+PLT), family = "binomial", data = ae.2)
  
  # Prediction for new doses
  ae.1.pre <- predict(AE1.m, newdata = pre.obs.AUCSS)
  ae.2.pre <- predict(AE2.m, newdata = pre.obs.AUCSS)
  
  AE.pred <- pre.obs.AUCSS %>% mutate(AE1 = ae.1.pre, AE2 = ae.2.pre)
  
  # summarize AE incidence rate for ATLL by dose
  Est12 <- AE.pred %>% filter(ATLL == 1) %>%
    dplyr::group_by(DOSE) %>%
    dplyr::summarize(ave_AUCSS = mean(pred.AUCSS),
                     rate1 = mean(plogis(AE1)),
                     rate2 = mean(plogis(AE2)))
  Est3 <- AE.pred %>% filter(ATLL == 1 & CLCR <= 60) %>%
    dplyr::group_by(DOSE) %>%
    dplyr::summarize(rate3 = mean(plogis(AE1)))
  Est.sum <- Est12 %>% mutate(rate3 = Est3$rate3)
  #Est.sum
  
  if(!is.null(output)){
    sink(output)
    print(summary(DE.m))
    print(summary(AE1.m))
    print(summary(AE2.m))
    sink()
    
  }
  if(model.object&data.save){
    list(dt = dt.new, Estimand = Est.sum, DE.m = DE.m, AE1.m = AE1.m, AE2.m = AE2.m)
  }else if(data.save){
    list(dt = dt.new, Estimand = Est.sum)
  }else{
    list(Estimand = Est.sum)
  }
}

DER.mod.result <- model.DER(obs, output = "D-E-R.txt")


model.DR <- function(dt, output = NULL, model.object = TRUE, data.save = TRUE){
  # Dose - Response models and predictions
  #### Dose reduction ####
  ae.1 <- dt %>% filter(FLAG == 8)
  # include BLDH, RACE, HEPAT ANY, WT
  AE1.m <- glm(DV~(DOSE)+(WT+AAG+CLCR+HEPAT+RACE+SEX+BLDH), family = "binomial", data = ae.1)
  
  #### PLT decrease ####
  ae.2 <- dt %>% filter(FLAG == 5)
  # include BLDH, RACE, HEPAT ANY, (baseline) PLT
  AE2.m <- glm(DV~DOSE+(WT+AAG+CLCR+HEPAT+RACE+SEX+BLDH+PLT), family = "binomial", data = ae.2)
  
  # prediction for new doses
  pre.obs.shell <- rbind(dt %>% mutate(DOSE = 150, AMT = 150),
                         dt %>% mutate(DOSE = 200, AMT = 200),
                         dt %>% mutate(DOSE = 250, AMT = 250),
                         dt %>% mutate(DOSE = 300, AMT = 300))
  
  # Prediction for new doses
  ae.1.pre <- predict(AE1.m, newdata = pre.obs.shell)
  ae.2.pre <- predict(AE2.m, newdata = pre.obs.shell)
  
  AE.pred <- pre.obs.shell %>% mutate(AE1 = ae.1.pre, AE2 = ae.2.pre)
  
  # summarize AE incidence rate for ATLL by dose
  Est12 <- AE.pred %>% filter(ATLL == 1) %>%
    dplyr::group_by(DOSE) %>%
    dplyr::summarize(rate1 = mean(plogis(AE1)),
                     rate2 = mean(plogis(AE2)))
  Est3 <- AE.pred %>% filter(ATLL == 1 & CLCR <= 60) %>%
    dplyr::group_by(DOSE) %>%
    dplyr::summarize(rate3 = mean(plogis(AE1)))
  Est.sum <- Est12 %>% mutate(rate3 = Est3$rate3)
  if(!is.null(output)){
    sink(output)
    print(summary(AE1.m))
    print(summary(AE2.m))
    sink()
  }
  if(model.object&data.save){
    list(dt = dt, Estimand = Est.sum, AE1.m = AE1.m, AE2.m = AE2.m)
  }else if(data.save){
    list(dt = dt, Estimand = Est.sum)
  }else{
    list(Estimand = Est.sum)
  }
}

DR.mod.result <- model.DR(obs, output = "D-R.txt")

# true AE incidence rate for ATLL by dose
read.csv("sample_true_prob.csv") %>%
  filter(ATLL == 1) %>% group_by(DOSE,FLAG) %>%
  dplyr::summarize(rate = mean(prob), AUCSS = mean(AUCSS)) %>%
  pivot_wider(names_from = "FLAG", values_from = "rate")

read.csv("sample_true_prob.csv") %>%
  filter(ATLL == 1, CLCR <= 60, FLAG == 8) %>% group_by(DOSE,FLAG) %>%
  dplyr::summarize(rate = mean(prob), AUCSS = mean(AUCSS)) %>%
  pivot_wider(names_from = "FLAG", values_from = "rate")


################### 1000 trials simulation ########################
load("trials.Rdata")
head(trial.dt)
trial.dt <- trial.dt %>%
  mutate(CRCL_f = ifelse(CLCR <= 60, 1, 0)) %>%
  mutate(SEX = factor(SEX, levels = c(0,1), labels = c("Male", "Female")),
         ECOGGE1 = factor(ECOGGE1, levels = c(0,1), labels = c("=0", ">=1")),
         HEPAT = factor(HEPAT, levels = c(0,1), labels = c("Normal", "Mild")),
         RACE = factor(RACE, levels = c(1,2,3), labels = c("Asian", "White", "Black")),
         LOCATION = factor(LOCATION, levels = c(0,1), labels = c("Japan", "USA")),
         CRCL_f = factor(CRCL_f, levels = c(0,1), labels = c(">60 mL/min", "<=60 mL/min"))) 

################### True Incidence Rate #####################
# true AE incidence rate for ATLL by dose     
true.AE <- read.csv("true_incidence_pred_sim.csv")
head(true.AE)
true.rate <- true.AE %>% filter(ATLL == 1) %>%
  group_by(DOSE,FLAG) %>%
  dplyr::summarize(rate = mean(mean.prob)) %>%
  pivot_wider(names_from = "FLAG", values_from = "rate")
true.rate2 <- true.AE %>% filter(ATLL == 1, CLCR <= 60, FLAG == 8) %>%
  group_by(DOSE,FLAG) %>%
  dplyr::summarize(rate = mean(mean.prob)) 
true.rate <- true.rate %>%
  ungroup() %>%
  rename(rate1 = `8`, rate2=`5`) %>%
  mutate(rate3 = true.rate2$rate) %>%
  select(DOSE, rate1, rate2, rate3) %>%
  pivot_longer(cols = c(rate1, rate2, rate3))
true.rate  
##### modeling and predicton for each simulated trial #####
trials.analysis <- unique(trial.dt$SIM) %>%
  map_df(function(trial){
    trial.sub <- trial.dt %>% filter(SIM==trial)
    DER.result <- model.DER(trial.sub, output = NULL, model.object = FALSE, data.save = FALSE)
    DR.result <- model.DR(trial.sub, output = NULL, model.object = FALSE, data.save = FALSE)
    DER.result <- DER.result[[1]] %>%
      pivot_longer(cols = c(rate1, rate2, rate3)) %>%
      mutate(SIM = trial,
             Method = "D-E-R")
    DR.result <- DR.result[[1]] %>%
      pivot_longer(cols = c(rate1, rate2, rate3)) %>%
      mutate(ave_AUCSS = NA,
             SIM = trial,
             Method = "D-R")
    rbind(DR.result, DER.result)
  })

trials.sum <- trials.analysis %>%
  merge(true.rate %>% rename(true.value = value),
        by = c("DOSE", "name"))
trials.sum2 <- trials.sum %>% 
  group_by(DOSE, name,Method) %>%
  summarise(ave_rate = mean(value),
            true_vaelue = mean(true.value),
            ave_bias = mean(value-true.value),
            MSE = mean((value-true.value)^2)) %>%
  arrange(name,DOSE,Method)
 trials.sum2 %>% filter(name == "rate1")
 trials.sum2 %>% filter(name == "rate2")
 trials.sum2 %>% filter(name == "rate3")
 
write.csv(trials.sum2,"1000trial_result.csv", row.names = F, quote = F)

rm(list=ls())
1. AE_data.csv is one of the simulated trial. AE_data.csv was generated from data_simulation.r.
2. command.r is for D-R and D-E-R analysis using 1000 simulated trials (trials.Rdata). 